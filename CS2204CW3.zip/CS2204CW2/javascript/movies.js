function getMovies() {
    return [
        {
            id:1,
            type:"now",
            thumbnail:"../pic/casablanca.png",
            src:"http://courses.cs.cityu.edu.hk/cs2204/video/casablanca-s.mp4",
            name:"Cassblanca",
            cast:"Humphrey Bogart, Ingrid Bergmen",
            director:"Michael Curtiz",
            duration: 130
        },
        {
            id:2,
            type:"now",
            thumbnail:"../pic/chocolate.jpg",
            name:"Chocolate",
            cast:"Juliette Binoche, Victoire Thivisol",
            director:"Lasse Hallström",
            duration: 121
        },
        {
            id:3,
            type:"now",
            thumbnail:"../pic/nature.jpg",
            src:"http://courses.cs.cityu.edu.hk/cs2204/video/nature.mp4",
            name:"Nature",
            cast:"N/A",
            director:"N/A",
            duration: "N/A"
        },
        {
            id:4,
            type:"upcoming",
            thumbnail:"../pic/wildlife.jpg",
            name:"Wildlife",
            cast:"Carey Mulligan, Jake Gyllenhaal",
            director:"Paul Dano",
            duration: 104
        },
        {
            id:5,
            type:"upcoming",
            thumbnail:"../pic/wonders.jpg",
            src:"https://courses.cs.cityu.edu.hk/cs2204/example/video/wonders.mp4",
            name:"Wonders",
            cast:"Julia Roberts, Owen Wilson",
            director:"Stephen Chbosky",
            duration: 113
        },
        {
            id:6,
            type:"upcoming",
            thumbnail:"../pic/barbecue.jpg",
            name:"Barbecue",
            cast:"Lambert Wilson, Franck Dubosc",
            director:"Éric Lavaine",
            duration: 98
        },
    ]
}
