var adVideos = ["https://courses.cs.cityu.edu.hk/cs2204/example/video/nature.mp4","https://courses.cs.cityu.edu.hk/cs2204/example/video/wonders.mp4","https://courses.cs.cityu.edu.hk/cs2204/example/video/bear.mp4"];
var thisAd = 0;
var videos = document.querySelector("video");
var imgs=document.querySelector("img");
function playVid(){
    videos.src=adVideos[thisAd+1];
    videos.load();
    videos.play();
    thisAd++;
    if(thisAd >=adVideos.length-1){
        thisAd=0;
    }
}
function switchVideo(){
    videos.pause();
    videos.src='https://courses.cs.cityu.edu.hk/cs2204/example/video/nature.mp4';
}
videos.addEventListener('ended',playVid,false);
imgs.addEventListener('click',switchVideo,false);


    